#!/usr/bin/env python3
# ============================================================================
# gen_ps_stats.py — Monte-Carlo statistics of progressive sharpening (PS).
# ============================================================================
# Standalone, run locally:  `python3 gen_ps_stats.py`
# (Pure standard library — no numpy required, though it will use numpy if found
#  for speed. Designed to be droppable into a Jupyter notebook cell too.)
#
# This is a faithful Python port of the gradient-flow dynamics in dynamics.js.
# For a grid of (init kind, width d, depth n) it draws MANY random networks from
# the standard width-normalized initialization, evolves each toward a fixed
# norm-1 whitened target, and records four probabilities:
#
#   p_init_sharpen : sharpness increases at the FIRST gradient step
#   p_ever_sharpen : sharpness ever exceeds its initial value during training
#   p_end_higher   : final sharpness exceeds initial sharpness
#   p_max_not_end  : the maximum sharpness is NOT at the final step
#
# NOTE: in the whitened case, sharpness tracks the function norm monotonically
# toward the target, so 'ever_sharpen' and 'end_higher' come out essentially
# identical (verified: 0/800 runs differed). All four are still recorded — they
# can diverge once non-whitened data is introduced — but for the current whitened
# model the distinct quantities are really {init_sharpen, ever_sharpen, max_not_end}.
#
# Results are written to ps_stats.json, shaped for the website to render as a
# table (the site will likely display only the first two).
#
# ---- dynamics recap (matches dynamics.js) ----------------------------------
# f(x) = B (w1 · x),  B = prod(b_i).  Whitened data with (1/N) Xᵀ X = I.
# Gradient flow (here explicit Euler):
#   dL/dw1 = (1/N) Σ_k r_k B x_k ;  dL/db_i = (1/N) Σ_k r_k (B/b_i)(w1·x_k)
# Sharpness = top eigenvalue of M = B²(I + S w1 w1ᵀ), S = Σ 1/b_i², i.e.
#   λ_parallel = B²(1 + S ||w1||²)   (whitened GN sharpness).
# ----------------------------------------------------------------------------

import json
import math
import random

try:
    import numpy as np
    HAVE_NUMPY = True
except ImportError:
    HAVE_NUMPY = False


# ── configuration ───────────────────────────────────────────────────────────
WIDTHS = [2, 3, 4, 5, 6]          # input width d
DEPTHS = [1, 2, 3, 4, 5]          # number of scalar (hidden) layers n
KINDS = ["gaussian", "uniform"]
N_SAMPLES = 1000                  # random networks per (kind, d, n) cell
TARGET_NORM = 1.0                 # ||p*||  (target along the first axis)

# integration settings (mirror the widget; tightened a little for stability)
ETA = 4e-3
MAX_STEPS = 4000
LOSS_TOL = 1e-3
SEED = 20240601
FLATTEN_TOL = 0.005   # >0.5% drop from running peak counts as flattening


# ── standard width-normalized initialization ────────────────────────────────
# First layer: per-coordinate variance 1/d, so ||w1||² ≈ 1 at any width.
# Scalar layers: unit variance.
def random_model(rng, kind, d, n):
    if kind == "gaussian":
        s = math.sqrt(1.0 / d)
        w1 = [rng.gauss(0.0, s) for _ in range(d)]
        b = [rng.gauss(0.0, 1.0) for _ in range(n)]
    else:  # uniform, matched variance: U[-a, a] with a = sqrt(3 * var)
        aw, ab = math.sqrt(3.0 / d), math.sqrt(3.0)
        w1 = [rng.uniform(-aw, aw) for _ in range(d)]
        b = [rng.uniform(-ab, ab) for _ in range(n)]
    return w1, b


# ── whitened dataset: ±√d on each axis, so (1/N) Xᵀ X = I ────────────────────
def whitened_data(d, pstar):
    X, y = [], []
    sd = math.sqrt(d)
    for j in range(d):
        e = [0.0] * d; e[j] = sd; X.append(e)
        e2 = [0.0] * d; e2[j] = -sd; X.append(e2)
    for xk in X:
        y.append(sum(pstar[i] * xk[i] for i in range(d)))
    return X, y


def layer_product(b):
    B = 1.0
    for bi in b:
        B *= bi
    return B


def sharpness(w1, b):
    # whitened GN sharpness = B²(1 + S ||w1||²), S = Σ 1/b_i²
    B = layer_product(b)
    S = sum(1.0 / (bi * bi) for bi in b)
    w1sq = sum(a * a for a in w1)
    return B * B * (1.0 + S * w1sq)


# ── one gradient-flow run; returns the sharpness time series ─────────────────
def run_sharpness_series(w1, b, X, y):
    d, n, N = len(w1), len(b), len(X)
    w1 = list(w1); b = list(b)
    series = [sharpness(w1, b)]
    prev_loss = None
    for _ in range(MAX_STEPS):
        B = layer_product(b)
        BoverBi = [B / bi for bi in b]
        gw1 = [0.0] * d
        gb = [0.0] * n
        loss = 0.0
        for k in range(N):
            xk = X[k]
            wx = sum(w1[j] * xk[j] for j in range(d))
            r = B * wx - y[k]
            loss += r * r
            rB = r * B
            for j in range(d):
                gw1[j] += rB * xk[j]
            rwx = r * wx
            for i in range(n):
                gb[i] += rwx * BoverBi[i]
        inv = 1.0 / N
        for j in range(d):
            w1[j] -= ETA * gw1[j] * inv
        for i in range(n):
            b[i] -= ETA * gb[i] * inv
        loss *= 0.5 * inv
        series.append(sharpness(w1, b))
        if loss < LOSS_TOL:
            break
        prev_loss = loss
    return series


# ── numpy fast path (same math, vectorized over the N=2d data points) ────────
def run_sharpness_series_np(w1, b, X, y):
    w1 = np.array(w1, float); b = np.array(b, float)
    X = np.array(X, float); y = np.array(y, float)
    N = X.shape[0]
    series = [float((np.prod(b) ** 2) * (1.0 + np.sum(1.0 / b**2) * np.sum(w1**2)))]
    for _ in range(MAX_STEPS):
        B = np.prod(b)
        wx = X @ w1
        r = B * wx - y
        loss = 0.5 * np.mean(r * r)
        gw1 = (B / N) * (X.T @ r)
        gb = np.array([(1.0 / N) * np.sum(r * wx * (B / bi)) for bi in b])
        w1 -= ETA * gw1
        b -= ETA * gb
        series.append(float((np.prod(b) ** 2) * (1.0 + np.sum(1.0 / b**2) * np.sum(w1**2))))
        if loss < LOSS_TOL:
            break
    return series


# ── per-run classification into the four events ──────────────────────────────
def classify(series):
    s0 = series[0]
    s_end = series[-1]
    s_max = max(series)
    i_max = series.index(s_max)
    eps = 1e-9

    # sharpen-then-flatten: rose above start, then later dropped >FLATTEN_TOL
    # below its running peak. The tolerance keeps step-size jitter from counting.
    peak = s0; sharpened = False; stf = False
    for s in series:
        if s > peak:
            peak = s
        if s > s0 * (1 + eps):
            sharpened = True
        if sharpened and s < peak * (1 - FLATTEN_TOL):
            stf = True
            break

    return {
        "init_sharpen": series[1] > s0 * (1 + eps) if len(series) > 1 else False,
        "ever_sharpen": s_max > s0 * (1 + eps),
        "end_higher": s_end > s0 * (1 + eps),
        "max_not_end": i_max < len(series) - 1 and s_max > s_end * (1 + eps),
        "sharpen_then_flatten": stf,
    }


def run_cell(kind, d, n, seed):
    rng = random.Random(seed)
    pstar = [0.0] * d; pstar[0] = TARGET_NORM
    X, y = whitened_data(d, pstar)
    runner = run_sharpness_series_np if HAVE_NUMPY else run_sharpness_series
    counts = {"init_sharpen": 0, "ever_sharpen": 0, "end_higher": 0, "max_not_end": 0, "sharpen_then_flatten": 0}
    for _ in range(N_SAMPLES):
        w1, b = random_model(rng, kind, d, n)
        series = runner(w1, b, X, y)
        ev = classify(series)
        for kkey in counts:
            counts[kkey] += 1 if ev[kkey] else 0
    return {kkey: counts[kkey] / N_SAMPLES for kkey in counts}


def main():
    print(f"PS statistics: {N_SAMPLES} samples per cell, "
          f"widths {WIDTHS}, depths {DEPTHS}, kinds {KINDS}")
    print(f"numpy: {'yes' if HAVE_NUMPY else 'no (pure-python, slower)'}\n")

    results = {}
    for kind in KINDS:
        results[kind] = {}
        for d in WIDTHS:
            results[kind][str(d)] = {}
            for n in DEPTHS:
                seed = SEED + hash((kind, d, n)) % 100000
                probs = run_cell(kind, d, n, seed)
                results[kind][str(d)][str(n)] = probs
                print(f"  {kind:8s} d={d} n={n}: "
                      f"init={probs['init_sharpen']:.3f} "
                      f"ever={probs['ever_sharpen']:.3f} "
                      f"end_higher={probs['end_higher']:.3f} "
                      f"max_not_end={probs['max_not_end']:.3f}")

    out = {
        "meta": {
            "n_samples": N_SAMPLES,
            "widths": WIDTHS,
            "depths": DEPTHS,
            "kinds": KINDS,
            "target_norm": TARGET_NORM,
            "eta": ETA,
            "max_steps": MAX_STEPS,
            "loss_tol": LOSS_TOL,
            "flatten_tol": FLATTEN_TOL,
            "metrics": [
                "init_sharpen", "ever_sharpen", "end_higher", "max_not_end", "sharpen_then_flatten",
            ],
        },
        "results": results,
    }
    with open("ps_stats.json", "w") as f:
        json.dump(out, f, indent=2)
    print("\nWrote ps_stats.json")


if __name__ == "__main__":
    main()
